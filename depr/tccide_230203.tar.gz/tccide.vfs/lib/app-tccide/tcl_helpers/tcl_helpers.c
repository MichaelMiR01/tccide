/* tcc4tcl_define 
int puts const char* string 
*/
#define puts tcl_puts
int tcl_puts(const char* string) {
    Tcl_Interp* ip = mod_Tcl_interp;
    if (ip==NULL) Tcl_Panic("No interp found to call tcl routine!");
    mod_Tcl_errorCode=0;
    Tcl_Obj*  argObjvArray [2];
    Tcl_Obj* funcname = Tcl_NewStringObj("puts",-1);
    Tcl_IncrRefCount(funcname);
    argObjvArray[0] = funcname;
    Tcl_Obj* target_1 = Tcl_NewStringObj(string,-1);
    Tcl_IncrRefCount(target_1);
    argObjvArray[1] = target_1;
    int rs = Tcl_EvalObjv(ip, 2, argObjvArray, 0);
    if(funcname!=NULL) Tcl_DecrRefCount(funcname);
    if(target_1 != NULL) Tcl_DecrRefCount(target_1);
    if(rs !=TCL_OK) {
        mod_Tcl_errorCode=rs;
        Tcl_Eval (ip, "puts {Error evaluating TCL-Function puts}; puts $errorInfo; flush stdout;");
        return EOF;
    }
    return 1; 
}


