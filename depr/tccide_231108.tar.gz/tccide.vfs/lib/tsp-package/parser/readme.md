This are precompiled binaries of the tclParser for win32 and linux64
