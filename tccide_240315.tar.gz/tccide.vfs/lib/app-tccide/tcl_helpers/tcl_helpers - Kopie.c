/* tcc4tcl_define 
int puts const char* string 
*/
#define puts tcl_puts
int tcl_puts(const char* string) {
    Tcl_Interp* ip = mod_Tcl_interp;
    if (ip==NULL) Tcl_Panic("No interp found to call tcl routine!");
    mod_Tcl_errorCode=0;
    Tcl_Obj*  argObjvArray [2];
    Tcl_Obj* funcname = Tcl_NewStringObj("puts",-1);
    Tcl_IncrRefCount(funcname);
    argObjvArray[0] = funcname;
    Tcl_Obj* target_1 = Tcl_NewStringObj(string,-1);
    Tcl_IncrRefCount(target_1);
    argObjvArray[1] = target_1;
    int rs = Tcl_EvalObjv(ip, 2, argObjvArray, 0);
    if(funcname!=NULL) Tcl_DecrRefCount(funcname);
    if(target_1 != NULL) Tcl_DecrRefCount(target_1);
    if(rs !=TCL_OK) {
        mod_Tcl_errorCode=rs;
        Tcl_Eval (ip, "puts {Error evaluating TCL-Function puts}; puts $errorInfo; flush stdout;");
        return EOF;
    }
    return 1; 
}


/* tcc4tcl_define 
char* _getsysconfig char *confreq
*/


/* get some information from the host compiler for configure */
/*
_getsysconfig compiler|version|minor|bigendian|triplet
*/


char* _getsysconfig(char *confreq)
{

#if defined(_WIN32)
#include <fcntl.h>
#endif

/* Define architecture */
#if defined(__i386__) || defined _M_IX86
# define TRIPLET_ARCH "i386"
#elif defined(__x86_64__) || defined _M_AMD64
# define TRIPLET_ARCH "x86_64"
#elif defined(__arm__)
# define TRIPLET_ARCH "arm"
#elif defined(__aarch64__)
# define TRIPLET_ARCH "aarch64"
#elif defined(__riscv) && defined(__LP64__)
# define TRIPLET_ARCH "riscv64"
#else
# define TRIPLET_ARCH "unknown"
#endif

/* Define OS */
#if defined (__linux__)
# define TRIPLET_OS "linux"
#elif defined (__FreeBSD__) || defined (__FreeBSD_kernel__)
# define TRIPLET_OS "kfreebsd"
#elif defined(__NetBSD__)
# define TRIPLET_OS "netbsd"
#elif defined(__OpenBSD__)
# define TRIPLET_OS "openbsd"
#elif defined(_WIN32)
# define TRIPLET_OS "win32"
#elif defined(__APPLE__)
# define TRIPLET_OS "darwin"
#elif !defined (__GNU__)
# define TRIPLET_OS "unknown"
#endif

#if defined __ANDROID__
# define ABI_PREFIX "android"
#else
# define ABI_PREFIX "gnu"
#endif

/* Define calling convention and ABI */
#if defined (__ARM_EABI__)
# if defined (__ARM_PCS_VFP)
#  define TRIPLET_ABI ABI_PREFIX"eabihf"
# else
#  define TRIPLET_ABI ABI_PREFIX"eabi"
# endif
#else
# define TRIPLET_ABI ABI_PREFIX
#endif

#if defined _WIN32
# define TRIPLET TRIPLET_ARCH "-" TRIPLET_OS
#elif defined __GNU__
# define TRIPLET TRIPLET_ARCH "-" TRIPLET_ABI
#else
# define TRIPLET TRIPLET_ARCH "-" TRIPLET_OS "-" TRIPLET_ABI
#endif

    char buf[128];
    char outbuf [2024];
    char req;
    unsigned int i;
    i=0;
    outbuf[0]='\0';
    while (i<strlen(confreq)) {
        req=confreq[i];
        i++;
    switch(req) {
        case 'b'://igendian
        {
            volatile unsigned foo = 0x01234567;
            sprintf(buf,*(unsigned char*)&foo == 0x67 ? "no" : "yes");
            break;
        }
#if defined(__clang__)
        case 'm'://inor
            sprintf(buf,"%d", __clang_minor__);
            break;
        case 'v'://ersion
            sprintf(buf,"%d", __clang_major__);
            break;
#elif defined(__TINYC__)
        case 'v'://ersion
            sprintf(buf,"0");
            break;
        case 'm'://inor
            sprintf(buf,"%d", __TINYC__);
            break;
#elif defined(_MSC_VER)
        case 'v'://ersion
            sprintf(buf,"0");
            break;
        case 'm'://inor
            sprintf(buf,"%d", _MSC_VER);
            break;
#elif defined(__GNUC__) && defined(__GNUC_MINOR__)
        /* GNU comes last as other compilers may add 'GNU' compatibility */
        case 'm'://inor
            sprintf(buf,"%d", __GNUC_MINOR__);
            break;
        case 'v'://ersion
            sprintf(buf,"%d", __GNUC__);
            break;
#else
        case 'm'://inor
        case 'v'://ersion
            sprintf(buf,"0");
            break;
#endif
        case 't'://riplet
            sprintf(buf,TRIPLET);
            break;
        case 'c'://ompiler
#if defined(__clang__)
            sprintf(buf,"clang");
#elif defined(__TINYC__)
            sprintf(buf,"tcc");
#elif defined(_MSC_VER)
            sprintf(buf,"msvc");
#elif defined(__GNUC__)
            sprintf(buf,"gcc");
#else
            sprintf(buf,"unknown");
#endif
            break;
        default:
            buf[0]=req;
            buf[1]='\0';
            break;
    }
    snprintf(outbuf + strlen(outbuf), 2024 - strlen(outbuf), "%s", buf);
    }
    return strdup(outbuf);
}

