/*-----------------------------------------------------------------------------
 * TclX_CtokenObjCmd --
 *     Implements the clength Tcl command:
 *         ctoken strvar separators
 *
 * Results:
 *      Returns the first token and removes it from the string variable.
 * FIX: Add command to make a list.  Better yet, a new cparse command thats
 * more flexable and includes this functionality.
 *-----------------------------------------------------------------------------
 */
static int 
TclX_CtokenObjCmd (ClientData clientData,
                   Tcl_Interp *interp,
                   int         objc,
                   Tcl_Obj   *CONST objv[])
{
    Tcl_Obj* stringVarObj;
    char* string;
    int strByteLen;
    int strByteIdx;
    char* separators;
    int separatorsLen;
    int tokenByteIdx;
    int tokenByteLen;
    Tcl_DString token;
    Tcl_UniChar uniChar;
    int utfBytes;
    Tcl_Obj *newVarValueObj;

    if (objc != 3) {
        Tcl_WrongNumArgs(interp, 3, objv, "strvar separators");
        return TCL_ERROR;
    }
    
    stringVarObj = Tcl_ObjGetVar2(interp, objv[1], NULL,
                                  TCL_LEAVE_ERR_MSG|TCL_PARSE_PART1);
    if (stringVarObj == NULL) {
        return TCL_ERROR;
    }
    string = Tcl_GetStringFromObj(stringVarObj, &strByteLen);
    separators = Tcl_GetStringFromObj(objv[2], &separatorsLen);

    /* Find the start of the token */
    strByteIdx = 0;
    while (strByteIdx < strByteLen) {
        utfBytes = Tcl_UtfToUniChar(string+strByteIdx, &uniChar);
        if (Tcl_UtfFindFirst(separators, uniChar) == NULL) {
            break;  /* Reached a separator */
        }
        strByteIdx += utfBytes;
    }
    tokenByteIdx = strByteIdx;

    /* Find end of the token */
    while (strByteIdx < strByteLen) {
        utfBytes = Tcl_UtfToUniChar(string+strByteIdx, &uniChar);
        if (Tcl_UtfFindFirst(separators, uniChar) != NULL) {
            break;  /* Reached a separator */
        }
        strByteIdx += utfBytes;
    }
    tokenByteLen = strByteIdx-tokenByteIdx;

    /* Copy token, before replacing variable, as its coming from old var */
    Tcl_DStringInit(&token);
    Tcl_DStringAppend(&token, string+tokenByteIdx, tokenByteLen);

    /* Set variable argument to new string. */
    newVarValueObj = Tcl_NewStringObj(string+strByteIdx,
                                      strByteLen-strByteIdx);
    if (Tcl_SetVar2Ex(interp, Tcl_GetStringFromObj(objv[1], NULL), NULL,
                      newVarValueObj,
                      TCL_LEAVE_ERR_MSG|TCL_PARSE_PART1) == NULL) {
        Tcl_DStringFree (&token);
        Tcl_DecrRefCount (newVarValueObj);
        return TCL_ERROR;
    }

    Tcl_DStringResult(interp, &token);
    return TCL_OK;
}
/*
Tcl_CreateObjCommand (interp, 
"ctoken",
TclX_CtokenObjCmd,
(ClientData) 0, 
(Tcl_CmdDeleteProc*) NULL);
*/
