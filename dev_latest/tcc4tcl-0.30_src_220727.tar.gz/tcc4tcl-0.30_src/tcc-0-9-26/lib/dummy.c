void __libtcc_dummy(void) {
}
