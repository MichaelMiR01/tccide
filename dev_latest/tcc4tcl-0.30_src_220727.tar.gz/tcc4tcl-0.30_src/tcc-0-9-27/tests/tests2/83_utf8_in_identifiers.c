#include <stdio.h>
double привет=0.1;
int Lefèvre=2;
int main(){
    printf("привет=%g\n",привет);
    printf("Lefèvre=%d\n",Lefèvre);
    return 0;
}
// pcc & tcc only
