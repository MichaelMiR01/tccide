#include <stdio.h>
#include <unistd.h>
void main () {
	printf("Hello");
}
