/* Z:/host/data/tcl/tcc_0.9.27-bin/tcc.exe -shared -Iinclude/ -Iinclude/1 -Iinclude/1/.. -Iinclude/generic -Iinclude/generic/.. -Iinclude/sdks -Iinclude/sdks/.. -Iinclude/sec_api -Iinclude/sec_api/.. -Iinclude/sys -Iinclude/sys/.. -Iinclude/tcc -Iinclude/tcc/.. -Iinclude/winapi -Iinclude/winapi/.. -Iinclude/xlib -Iinclude/xlib/.. -Itsp-package/native/clang/ testpkg.c -ltclstub86elf -ltkstub86elf -Llib  */

/* Z:/host/data/tcl/gcc.exe -shared -s -m32 -D_WIN32 -static-libgcc -Iincludetcl -Iinclude/xlib -Itsp-package/native/clang/ testpkg.c -Llib -ltclstub86 -ltkstub86 -Llib -otestpkg.dll -Ofast*/

/* i686-w64-mingw32-gcc -shared -s -m32 -D_WIN32 -static-libgcc -Iincludetcl -Iinclude/xlib -Itsp-package/native/clang/ testpkg.c -Llib -ltclstub86 -ltkstub86 -Llib  -otestpkg.dll -Ofast*/

#define USE_TCL_STUBS 1
#include <tcl.h>
        /* don't forget to declare includedir tsp-package/native/clang/ in the right way*/
        #include "TSP_cmd.c"
        #include "TSP_func.c"
        #include "TSP_util.c"
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define ERROR_EXIT goto error_exit
#define CLEANUP  \
\
    \
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } \
    \
    \

#define RETURN_VALUE_CLEANUP
#define RETURN_VALUE returnValue
/* 
 * compiled proc implementation 
 *
 */
Tcl_WideInt
TSP_UserDirect_fib0(Tcl_Interp* interp, int* rc  , Tcl_WideInt __n ) {
    static int directInit = 0;
    int i;          /* for loop */
    int len;        /* len, idx1, idx2, str, str2 -for use by lang_string, et.al. */
    int idx1;
    int idx2;
    char* str1;     
    char* str2;     
    char* exprErrMsg = NULL;
    Tcl_Obj* _tmpVar_cmdResultObj = NULL;
    /* Tcl_CallFrame commented out not to use internal funcs MiR 2022-04-23
    Tcl_CallFrame* frame = NULL; 
    */
    Tcl_WideInt returnValue = 0;
    Tcl_Obj** foreachObjv_0 = NULL;
    static (* TSP_UserDirect_fib)();
    /* stack allocated strings */
    /* variables defined in proc, plus temp vars */
    Tcl_WideInt _tmpVar_int_1 = 0;
    Tcl_WideInt _tmpVar_int_2 = 0;
    Tcl_WideInt _tmpVar_int_3 = 0;
    Tcl_WideInt __fib_1 = 0;
    Tcl_WideInt __fib_2 = 0;
    Tcl_WideInt __result = 0;
    /* constants used for direct tcl and tcl invoked commands */
    /* initialize return value */
    /* initialize string vars */
    /* var arguments need to be preserved, since they are released in CLEANUP */
    /* string arguments need to be copied (FIXME: investigate using COW for strings) */
    /* initialize function pointers for calling other compiled procs, constants */
    if (! directInit) {
        directInit = 1;
        TSP_UserDirect_fib =  TSP_User_getCmd(interp, "fib");
    }
    /* Tcl_CallFrame is dangerous since it is buried deep in the tcl_internals stubs table */
    /* could easily break in future TCL_VERSION versions */
    /* Made it functional against 8.6.6 with no guarantee */
    /* Commented out not to use internal funcs MiR 2022-04-23 */
    /* Maybe this has sideeffects like polluting the global namespace when spilling vars*/
    /*
    frame = (Tcl_CallFrame*) ckalloc(sizeof(Tcl_CallFrame));
    Tcl_PushCallFrame(interp, frame, Tcl_GetGlobalNamespace(interp), 1);
    */
    *rc = TCL_OK;     
    /* code must return a value as defined by procdef (unless void), else will raise a compile error */
    /* does only gcc do this with the right option?  what about tcc/clang/msvc++? */
    /******** fib0 5: if {$n < 2} {return 1} */
    /***** ::tsp::gen_command_if */
    if ( (__n < 2) ) {
        /******** fib0 5: return 1 */
        /***** ::tsp::gen_command_return */
        /***** ::tsp::gen_assign_scalar_text */
        _tmpVar_int_1 = 1LL;
        /* ::tsp::lang_return */
        returnValue = _tmpVar_int_1;
        *rc = TCL_OK;
        CLEANUP;
        /* returnValue is cleaned up by calling proc */;
        return RETURN_VALUE;
    }
    /******** fib0 7: set fib_2 [fib [expr {$n -2}]] */
    /***** ::tsp::generate_set assign from command */
    /******** fib0 7: fib [expr {$n -2}] */
    /***** ::tsp::gen_direct_tsp_compiled fib */
    /***** ::tsp::generate_set assign from command */
    /******** fib0 7: expr {$n -2} */
    _tmpVar_int_2 = (__n - 2);
    /***** ::tsp::gen_assign_scalar_scalar */
    _tmpVar_int_1 = (Tcl_WideInt) _tmpVar_int_2;
    /*  ::tsp::lang_invoke_tsp_compiled */
    _tmpVar_int_3 = (Tcl_WideInt) TSP_UserDirect_fib(interp, rc, _tmpVar_int_1);
    if (*rc != TCL_OK) {
        ERROR_EXIT;
    }
    /***** ::tsp::gen_assign_scalar_scalar */
    __fib_2 = (Tcl_WideInt) _tmpVar_int_3;
    /******** fib0 8: set fib_1 [fib [expr {$n -1}]] */
    /***** ::tsp::generate_set assign from command */
    /******** fib0 8: fib [expr {$n -1}] */
    /***** ::tsp::gen_direct_tsp_compiled fib */
    /***** ::tsp::generate_set assign from command */
    /******** fib0 8: expr {$n -1} */
    _tmpVar_int_2 = (__n - 1);
    /***** ::tsp::gen_assign_scalar_scalar */
    _tmpVar_int_1 = (Tcl_WideInt) _tmpVar_int_2;
    /*  ::tsp::lang_invoke_tsp_compiled */
    _tmpVar_int_3 = (Tcl_WideInt) TSP_UserDirect_fib(interp, rc, _tmpVar_int_1);
    if (*rc != TCL_OK) {
        ERROR_EXIT;
    }
    /***** ::tsp::gen_assign_scalar_scalar */
    __fib_1 = (Tcl_WideInt) _tmpVar_int_3;
    /******** fib0 9: set result [expr {$fib_2 + $fib_1}] */
    /***** ::tsp::generate_set assign from command */
    /******** fib0 9: expr {$fib_2 + $fib_1} */
    _tmpVar_int_1 = (__fib_2 + __fib_1);
    /***** ::tsp::gen_assign_scalar_scalar */
    __result = (Tcl_WideInt) _tmpVar_int_1;
    /******** fib0 10: return $result */
    /***** ::tsp::gen_command_return */
    /***** ::tsp::gen_assign_scalar_scalar */
    _tmpVar_int_1 = (Tcl_WideInt) __result;
    /* ::tsp::lang_return */
    returnValue = _tmpVar_int_1;
    *rc = TCL_OK;
    CLEANUP;
    /* returnValue is cleaned up by calling proc */;
    return RETURN_VALUE;
    /* if void, then we can jump to normal_exit, if not-void, then that means the proc fell through */
    /* without returning a value.  in that case, set result and return error code*/
    Tcl_SetResult(interp, "end of proc encountered without 'return' command, proc type: int", TCL_STATIC); goto error_exit;    
  error_exit:
    *rc = TCL_ERROR;
  normal_exit:
    CLEANUP;
    RETURN_VALUE_CLEANUP;
    return RETURN_VALUE;
}
/* redefine macros for the Tcl interface function */
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define CLEANUP \

#define RETURN_VALUE_CLEANUP 
#define RETURN_VALUE 
#define ERROR_EXIT goto error_exit
/* 
 * Tcl command interface 
 *
 */
int fib0(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) {
    int _rc;
    int* rc = &_rc;;
    Tcl_WideInt returnValue = 0;
    /* variables used by this command, assigned from objv array */
    Tcl_WideInt __n = 0;
    /* allow other compiled procs to find the this proc function at runtime, see TSP_cmd.TSP_User_getCmd() */
    if (clientData != NULL && objc == 0) {
        void** cd = clientData;
        *cd = (void*) TSP_UserDirect_fib0;
        return TCL_OK;
    }
    /* check arg count */
    if (objc != 2) {
        Tcl_WrongNumArgs(interp, 1, objv, "n");
        return TCL_ERROR;
    }
    /* assign arg variable from objv array */
    /* ::tsp::lang_convert_int_var */
    if ((*rc = Tcl_GetWideIntFromObj(interp, objv[1], &__n)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 1 to int", "objv[1]", (char *) NULL);
        ERROR_EXIT;
    }
    /* invoke compiled proc method */
    _rc = TCL_OK;
    returnValue = TSP_UserDirect_fib0(interp, &_rc , __n);
    if (_rc == TCL_OK) {
        Tcl_SetObjResult(interp, Tcl_NewWideIntObj((Tcl_WideInt) returnValue));
        /* ok to fall through */
    }
  error_exit:
    CLEANUP;
    return _rc;
}
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define ERROR_EXIT goto error_exit
#define CLEANUP  \
\
    \
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } \
    \
    \

#define RETURN_VALUE_CLEANUP
#define RETURN_VALUE returnValue
/* 
 * compiled proc implementation 
 *
 */
Tcl_WideInt
TSP_UserDirect_fib(Tcl_Interp* interp, int* rc  , Tcl_WideInt __n ) {
    static int directInit = 0;
    int i;          /* for loop */
    int len;        /* len, idx1, idx2, str, str2 -for use by lang_string, et.al. */
    int idx1;
    int idx2;
    char* str1;     
    char* str2;     
    char* exprErrMsg = NULL;
    Tcl_Obj* _tmpVar_cmdResultObj = NULL;
    /* Tcl_CallFrame commented out not to use internal funcs MiR 2022-04-23
    Tcl_CallFrame* frame = NULL; 
    */
    Tcl_WideInt returnValue = 0;
    Tcl_Obj** foreachObjv_0 = NULL;
    static (* TSP_UserDirect_fib)();
    /* stack allocated strings */
    /* variables defined in proc, plus temp vars */
    Tcl_WideInt _tmpVar_int_1 = 0;
    Tcl_WideInt _tmpVar_int_2 = 0;
    Tcl_WideInt _tmpVar_int_3 = 0;
    Tcl_WideInt __fib_1 = 0;
    Tcl_WideInt __fib_2 = 0;
    Tcl_WideInt __result = 0;
    /* constants used for direct tcl and tcl invoked commands */
    /* initialize return value */
    /* initialize string vars */
    /* var arguments need to be preserved, since they are released in CLEANUP */
    /* string arguments need to be copied (FIXME: investigate using COW for strings) */
    /* initialize function pointers for calling other compiled procs, constants */
    if (! directInit) {
        directInit = 1;
        TSP_UserDirect_fib =  TSP_User_getCmd(interp, "fib");
    }
    /* Tcl_CallFrame is dangerous since it is buried deep in the tcl_internals stubs table */
    /* could easily break in future TCL_VERSION versions */
    /* Made it functional against 8.6.6 with no guarantee */
    /* Commented out not to use internal funcs MiR 2022-04-23 */
    /* Maybe this has sideeffects like polluting the global namespace when spilling vars*/
    /*
    frame = (Tcl_CallFrame*) ckalloc(sizeof(Tcl_CallFrame));
    Tcl_PushCallFrame(interp, frame, Tcl_GetGlobalNamespace(interp), 1);
    */
    *rc = TCL_OK;     
    /* code must return a value as defined by procdef (unless void), else will raise a compile error */
    /* does only gcc do this with the right option?  what about tcc/clang/msvc++? */
    /******** fib 5: if {$n < 2} {return 1} */
    /***** ::tsp::gen_command_if */
    if ( (__n < 2) ) {
        /******** fib 5: return 1 */
        /***** ::tsp::gen_command_return */
        /***** ::tsp::gen_assign_scalar_text */
        _tmpVar_int_1 = 1LL;
        /* ::tsp::lang_return */
        returnValue = _tmpVar_int_1;
        *rc = TCL_OK;
        CLEANUP;
        /* returnValue is cleaned up by calling proc */;
        return RETURN_VALUE;
    }
    /******** fib 6: set fib_2 [fib [expr {$n -2}]] */
    /***** ::tsp::generate_set assign from command */
    /******** fib 6: fib [expr {$n -2}] */
    /***** ::tsp::gen_direct_tsp_compiled fib */
    /***** ::tsp::generate_set assign from command */
    /******** fib 6: expr {$n -2} */
    _tmpVar_int_2 = (__n - 2);
    /***** ::tsp::gen_assign_scalar_scalar */
    _tmpVar_int_1 = (Tcl_WideInt) _tmpVar_int_2;
    /*  ::tsp::lang_invoke_tsp_compiled */
    _tmpVar_int_3 = (Tcl_WideInt) TSP_UserDirect_fib(interp, rc, _tmpVar_int_1);
    if (*rc != TCL_OK) {
        ERROR_EXIT;
    }
    /***** ::tsp::gen_assign_scalar_scalar */
    __fib_2 = (Tcl_WideInt) _tmpVar_int_3;
    /******** fib 7: set fib_1 [fib [expr {$n -1}]] */
    /***** ::tsp::generate_set assign from command */
    /******** fib 7: fib [expr {$n -1}] */
    /***** ::tsp::gen_direct_tsp_compiled fib */
    /***** ::tsp::generate_set assign from command */
    /******** fib 7: expr {$n -1} */
    _tmpVar_int_2 = (__n - 1);
    /***** ::tsp::gen_assign_scalar_scalar */
    _tmpVar_int_1 = (Tcl_WideInt) _tmpVar_int_2;
    /*  ::tsp::lang_invoke_tsp_compiled */
    _tmpVar_int_3 = (Tcl_WideInt) TSP_UserDirect_fib(interp, rc, _tmpVar_int_1);
    if (*rc != TCL_OK) {
        ERROR_EXIT;
    }
    /***** ::tsp::gen_assign_scalar_scalar */
    __fib_1 = (Tcl_WideInt) _tmpVar_int_3;
    /******** fib 8: set result [expr {$fib_2 + $fib_1}] */
    /***** ::tsp::generate_set assign from command */
    /******** fib 8: expr {$fib_2 + $fib_1} */
    _tmpVar_int_1 = (__fib_2 + __fib_1);
    /***** ::tsp::gen_assign_scalar_scalar */
    __result = (Tcl_WideInt) _tmpVar_int_1;
    /******** fib 9: return $result */
    /***** ::tsp::gen_command_return */
    /***** ::tsp::gen_assign_scalar_scalar */
    _tmpVar_int_1 = (Tcl_WideInt) __result;
    /* ::tsp::lang_return */
    returnValue = _tmpVar_int_1;
    *rc = TCL_OK;
    CLEANUP;
    /* returnValue is cleaned up by calling proc */;
    return RETURN_VALUE;
    /* if void, then we can jump to normal_exit, if not-void, then that means the proc fell through */
    /* without returning a value.  in that case, set result and return error code*/
    Tcl_SetResult(interp, "end of proc encountered without 'return' command, proc type: int", TCL_STATIC); goto error_exit;    
  error_exit:
    *rc = TCL_ERROR;
  normal_exit:
    CLEANUP;
    RETURN_VALUE_CLEANUP;
    return RETURN_VALUE;
}
/* redefine macros for the Tcl interface function */
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define CLEANUP \

#define RETURN_VALUE_CLEANUP 
#define RETURN_VALUE 
#define ERROR_EXIT goto error_exit
/* 
 * Tcl command interface 
 *
 */
int fib(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) {
    int _rc;
    int* rc = &_rc;;
    Tcl_WideInt returnValue = 0;
    /* variables used by this command, assigned from objv array */
    Tcl_WideInt __n = 0;
    /* allow other compiled procs to find the this proc function at runtime, see TSP_cmd.TSP_User_getCmd() */
    if (clientData != NULL && objc == 0) {
        void** cd = clientData;
        *cd = (void*) TSP_UserDirect_fib;
        return TCL_OK;
    }
    /* check arg count */
    if (objc != 2) {
        Tcl_WrongNumArgs(interp, 1, objv, "n");
        return TCL_ERROR;
    }
    /* assign arg variable from objv array */
    /* ::tsp::lang_convert_int_var */
    if ((*rc = Tcl_GetWideIntFromObj(interp, objv[1], &__n)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 1 to int", "objv[1]", (char *) NULL);
        ERROR_EXIT;
    }
    /* invoke compiled proc method */
    _rc = TCL_OK;
    returnValue = TSP_UserDirect_fib(interp, &_rc , __n);
    if (_rc == TCL_OK) {
        Tcl_SetObjResult(interp, Tcl_NewWideIntObj((Tcl_WideInt) returnValue));
        /* ok to fall through */
    }
  error_exit:
    CLEANUP;
    return _rc;
}
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define ERROR_EXIT goto error_exit
#define CLEANUP  \
\
    \
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } \
    \
    if (_tmpVar_var_1 != NULL) { Tcl_DecrRefCount(_tmpVar_var_1); _tmpVar_var_1 = NULL; } \
    if (__char != NULL) { Tcl_DecrRefCount(__char); __char = NULL; } \
    if (__list != NULL) { Tcl_DecrRefCount(__list); __list = NULL; } \
    \
    Tcl_DStringFree(__str);\
    Tcl_DStringFree(_tmpVar_string_1);\
    Tcl_DStringFree(__word);\

#define RETURN_VALUE_CLEANUP
#define RETURN_VALUE returnValue
/* 
 * compiled proc implementation 
 *
 */
Tcl_Obj*
TSP_UserDirect_wordsplit(Tcl_Interp* interp, int* rc  , Tcl_DString* Caller___str ) {
    static int directInit = 0;
    int i;          /* for loop */
    int len;        /* len, idx1, idx2, str, str2 -for use by lang_string, et.al. */
    int idx1;
    int idx2;
    char* str1;     
    char* str2;     
    char* exprErrMsg = NULL;
    Tcl_Obj* _tmpVar_cmdResultObj = NULL;
    /* Tcl_CallFrame commented out not to use internal funcs MiR 2022-04-23
    Tcl_CallFrame* frame = NULL; 
    */
    Tcl_Obj* returnValue = NULL;
    Tcl_Obj** foreachObjv_0 = NULL;
    Tcl_Obj*  argObjvArray_1[4];
    int       argObjc_1 = 0;
    Tcl_Obj** foreachObjv_1 = NULL;
    /* stack allocated strings */
    Tcl_DString Proc___str;
    Tcl_DString Proc__tmpVar_string_1;
    Tcl_DString Proc___word;
    /* variables defined in proc, plus temp vars */
    Tcl_DString* __str;
    int _tmpVar_boolean_1 = 0;
    Tcl_WideInt _tmpVar_int_1 = 0;
    Tcl_DString* _tmpVar_string_1;
    Tcl_Obj* _tmpVar_var_1 = NULL;
    Tcl_Obj* __char = NULL;
    Tcl_WideInt __i = 0;
    int __is_space = 0;
    Tcl_WideInt __len = 0;
    Tcl_Obj* __list = NULL;
    Tcl_WideInt __strlen = 0;
    Tcl_DString* __word;
    /* constants used for direct tcl and tcl invoked commands */
    /* const: is */
    static Tcl_Obj* _constant_1 = NULL;
    /* const: space */
    static Tcl_Obj* _constant_2 = NULL;
    /* initialize return value */
    /* initialize string vars */
    Tcl_DStringInit(&Proc___str);
    __str = &Proc___str;
    Tcl_DStringInit(&Proc__tmpVar_string_1);
    _tmpVar_string_1 = &Proc__tmpVar_string_1;
    Tcl_DStringInit(&Proc___word);
    __word = &Proc___word;
    /* var arguments need to be preserved, since they are released in CLEANUP */
    /* string arguments need to be copied (FIXME: investigate using COW for strings) */
    Tcl_DStringAppend(__str, Tcl_DStringValue(Caller___str), Tcl_DStringLength(Caller___str));
    /* initialize function pointers for calling other compiled procs, constants */
    if (! directInit) {
        directInit = 1;
        _constant_1 = TSP_Util_const_string("is");
        _constant_2 = TSP_Util_const_string("space");
    }
    /* Tcl_CallFrame is dangerous since it is buried deep in the tcl_internals stubs table */
    /* could easily break in future TCL_VERSION versions */
    /* Made it functional against 8.6.6 with no guarantee */
    /* Commented out not to use internal funcs MiR 2022-04-23 */
    /* Maybe this has sideeffects like polluting the global namespace when spilling vars*/
    /*
    frame = (Tcl_CallFrame*) ckalloc(sizeof(Tcl_CallFrame));
    Tcl_PushCallFrame(interp, frame, Tcl_GetGlobalNamespace(interp), 1);
    */
    *rc = TCL_OK;     
    /* code must return a value as defined by procdef (unless void), else will raise a compile error */
    /* does only gcc do this with the right option?  what about tcc/clang/msvc++? */
    /******** wordsplit 7: set list {} */
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_string */
    __list = TSP_Util_lang_assign_var_string_const(__list, "");
    /******** wordsplit 8: set word {} */
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_string_const */
    Tcl_DStringSetLength(__word,0);
    Tcl_DStringAppend(__word, "", -1);
    /******** wordsplit 9: set strlen [string length $str] */
    /***** ::tsp::generate_set assign from command */
    /******** wordsplit 9: string length $str */
    /***** ::tsp::gen_command_string_length */
    /* lang_string_length */
    _tmpVar_int_1 = Tcl_NumUtfChars(Tcl_DStringValue(__str), Tcl_DStringLength(__str));
    /***** ::tsp::gen_assign_scalar_scalar */
    __strlen = (Tcl_WideInt) _tmpVar_int_1;
    /******** wordsplit 10: for {set i 0} {$i < $strlen} {incr i} {. */
    /***** ::tsp::gen_command_for */
    /* ::tsp::gen_command_for initializer*/
    /******** wordsplit 10: set i 0 */
    /***** ::tsp::gen_assign_scalar_text */
    __i = 0LL;
    /* ::tsp::lang_while */
    /* evaluate condition */
    _tmpVar_boolean_1 = (__i < __strlen);
    while ( _tmpVar_boolean_1 ) {
        /******** wordsplit 11: set char [string index $str $i] */
        /***** ::tsp::generate_set assign from command */
        /******** wordsplit 11: string index $str $i */
        /***** ::tsp::gen_command_string_index */
        /* lang_string_index */
        len = Tcl_NumUtfChars(Tcl_DStringValue(__str), Tcl_DStringLength(__str));
        Tcl_DStringSetLength(_tmpVar_string_1, 0);
        if ((__i >= 0) && ((int) __i < len)) {
            str1 = (char*) Tcl_UtfAtIndex(Tcl_DStringValue(__str), (int) __i);
            str2 = (char*) Tcl_UtfNext(str1);
            Tcl_DStringAppend(_tmpVar_string_1, str1, str2 - str1);
        } else {
            /* index out of range, leave result as empty string */;
        }
        /***** ::tsp::gen_assign_scalar_scalar */
        /* ::tsp::lang_assign_var_string */
        __char = TSP_Util_lang_assign_var_string(__char, _tmpVar_string_1);
        /******** wordsplit 12: set is_space [string is space $char] */
        /***** ::tsp::generate_set assign from command */
        /******** wordsplit 12: string is space $char */
        /***** ::tsp::gen_direct_tcl string */
        argObjvArray_1[0] = NULL;
        argObjvArray_1[1] = _constant_1;
        argObjvArray_1[2] = _constant_2;
        argObjvArray_1[3] = __char;
        /*  ::tsp::lang_invoke_builtin */
        if ((*rc = (TSP_Cmd_builtin_string) ((ClientData)NULL, interp,  4, argObjvArray_1)) != TCL_OK) {
            ERROR_EXIT;
        }
        if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } 
        _tmpVar_cmdResultObj = Tcl_GetObjResult(interp);
        Tcl_IncrRefCount(_tmpVar_cmdResultObj);
        /***** ::tsp::gen_assign_scalar_scalar */
        /* ::tsp::lang_convert_boolean_var */
        if ((*rc = Tcl_GetBooleanFromObj(interp, _tmpVar_cmdResultObj, &__is_space)) != TCL_OK) {
            Tcl_AppendResult(interp, "tsp runtime error, file: \"_\" proc: \"wordsplit\" line: 12 - \"unable to convert var to boolean, \\\"_tmpVar_cmdResultObj\\\", value: \"", Tcl_GetString(_tmpVar_cmdResultObj), (char *) NULL);
            ERROR_EXIT;
        }
        /******** wordsplit 13: if {$is_space} {....set len [string length $word */
        /***** ::tsp::gen_command_if */
        if ( __is_space ) {
                /******** wordsplit 14: set len [string length $word] */
                /***** ::tsp::generate_set assign from command */
                /******** wordsplit 14: string length $word */
                /***** ::tsp::gen_command_string_length */
                /* lang_string_length */
                _tmpVar_int_1 = Tcl_NumUtfChars(Tcl_DStringValue(__word), Tcl_DStringLength(__word));
                /***** ::tsp::gen_assign_scalar_scalar */
                __len = (Tcl_WideInt) _tmpVar_int_1;
                /******** wordsplit 15: if {$len > 0} {.....lappend list $word....} */
                /***** ::tsp::gen_command_if */
                if ( (__len > 0) ) {
                        /******** wordsplit 16: lappend list $word */
                        /***** ::tsp::gen_command_lappend */
                        /* ::tsp::lang_dup_var_if_shared */
                        if (__list != NULL) {
                            if (Tcl_IsShared(__list)) {
                                Tcl_DecrRefCount(__list);
                                __list = Tcl_DuplicateObj(__list);
                                Tcl_IncrRefCount(__list);
                            }
                        } else {
                            __list = Tcl_NewStringObj("",-1);
                            Tcl_IncrRefCount(__list);
                        }
                        /***** ::tsp::gen_assign_scalar_scalar */
                        /* ::tsp::lang_assign_var_string */
                        _tmpVar_var_1 = TSP_Util_lang_assign_var_string(_tmpVar_var_1, __word);
                        /* ::tsp::lang_lappend_var */
                        Tcl_ListObjAppendElement(interp, __list, _tmpVar_var_1);
                }
                /******** wordsplit 18: set word {} */
                /***** ::tsp::gen_assign_scalar_text */
                /* ::tsp::lang_assign_string_const */
                Tcl_DStringSetLength(__word,0);
                Tcl_DStringAppend(__word, "", -1);
        } else {
                /******** wordsplit 20: append word $char */
                /***** ::tsp::gen_command_append */
                /***** ::tsp::gen_assign_scalar_scalar */
                /* ::tsp::lang_convert_string_var */
                Tcl_DStringSetLength(_tmpVar_string_1, 0);
                _tmpVar_string_1 = TSP_Util_lang_convert_string_var(_tmpVar_string_1, __char);
                /* ::tsp::lang_append_string */
                Tcl_DStringAppend(__word, Tcl_DStringValue(_tmpVar_string_1), Tcl_DStringLength(_tmpVar_string_1));
        }
        /* ::tsp::gen_command_for postloop */
        /******** wordsplit 10: incr i */
        __i = __i + (1);
        /* evaluate condition */
        _tmpVar_boolean_1 = (__i < __strlen);
    }
    /******** wordsplit 23: set len [string length $word] */
    /***** ::tsp::generate_set assign from command */
    /******** wordsplit 23: string length $word */
    /***** ::tsp::gen_command_string_length */
    /* lang_string_length */
    _tmpVar_int_1 = Tcl_NumUtfChars(Tcl_DStringValue(__word), Tcl_DStringLength(__word));
    /***** ::tsp::gen_assign_scalar_scalar */
    __len = (Tcl_WideInt) _tmpVar_int_1;
    /******** wordsplit 24: if {$len > 0} {...lappend list $word..} */
    /***** ::tsp::gen_command_if */
    if ( (__len > 0) ) {
        /******** wordsplit 25: lappend list $word */
        /***** ::tsp::gen_command_lappend */
        /* ::tsp::lang_dup_var_if_shared */
        if (__list != NULL) {
            if (Tcl_IsShared(__list)) {
                Tcl_DecrRefCount(__list);
                __list = Tcl_DuplicateObj(__list);
                Tcl_IncrRefCount(__list);
            }
        } else {
            __list = Tcl_NewStringObj("",-1);
            Tcl_IncrRefCount(__list);
        }
        /***** ::tsp::gen_assign_scalar_scalar */
        /* ::tsp::lang_assign_var_string */
        _tmpVar_var_1 = TSP_Util_lang_assign_var_string(_tmpVar_var_1, __word);
        /* ::tsp::lang_lappend_var */
        Tcl_ListObjAppendElement(interp, __list, _tmpVar_var_1);
    }
    /******** wordsplit 27: return $list */
    /***** ::tsp::gen_command_return */
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_assign_var_var */
    _tmpVar_var_1 = TSP_Util_lang_assign_var_var(_tmpVar_var_1, __list);
    Tcl_IncrRefCount(_tmpVar_var_1);
    /* ::tsp::lang_return */
    returnValue = _tmpVar_var_1;
    Tcl_IncrRefCount(returnValue);
    *rc = TCL_OK;
    CLEANUP;
    /* returnValue is cleaned up by calling proc */;
    return RETURN_VALUE;
    /* if void, then we can jump to normal_exit, if not-void, then that means the proc fell through */
    /* without returning a value.  in that case, set result and return error code*/
    Tcl_SetResult(interp, "end of proc encountered without 'return' command, proc type: var", TCL_STATIC); goto error_exit;    
  error_exit:
    *rc = TCL_ERROR;
  normal_exit:
    CLEANUP;
    RETURN_VALUE_CLEANUP;
    return RETURN_VALUE;
}
/* redefine macros for the Tcl interface function */
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define CLEANUP  \
\
    Tcl_DStringFree(__str);\

#define RETURN_VALUE_CLEANUP 
#define RETURN_VALUE 
#define ERROR_EXIT goto error_exit
/* 
 * Tcl command interface 
 *
 */
int wordsplit(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) {
    int _rc;
    int* rc = &_rc;;
    Tcl_Obj* returnValue = NULL;
    /* variables used by this command, assigned from objv array */
    Tcl_DString Cmd___str;
    Tcl_DString* __str;
    Tcl_DStringInit(&Cmd___str);
    __str = &Cmd___str;
    /* allow other compiled procs to find the this proc function at runtime, see TSP_cmd.TSP_User_getCmd() */
    if (clientData != NULL && objc == 0) {
        void** cd = clientData;
        *cd = (void*) TSP_UserDirect_wordsplit;
        return TCL_OK;
    }
    /* check arg count */
    if (objc != 2) {
        Tcl_WrongNumArgs(interp, 1, objv, "str");
        return TCL_ERROR;
    }
    /* assign arg variable from objv array */
    /* ::tsp::lang_convert_string_var */
    Tcl_DStringSetLength(__str, 0);
    __str = TSP_Util_lang_convert_string_var(__str, objv[1]);
    /* invoke compiled proc method */
    _rc = TCL_OK;
    returnValue = TSP_UserDirect_wordsplit(interp, &_rc , __str);
    if (_rc == TCL_OK) {
        Tcl_SetObjResult(interp, returnValue);
        /* ok to fall through */
    }
  error_exit:
    CLEANUP;
    return _rc;
}
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define ERROR_EXIT goto error_exit
#define CLEANUP  \
\
    \
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } \
    \
    if (_tmpVar_var_1 != NULL) { Tcl_DecrRefCount(_tmpVar_var_1); _tmpVar_var_1 = NULL; } \
    if (_tmpVar_var_2 != NULL) { Tcl_DecrRefCount(_tmpVar_var_2); _tmpVar_var_2 = NULL; } \
    if (__buf != NULL) { Tcl_DecrRefCount(__buf); __buf = NULL; } \
    if (__ll != NULL) { Tcl_DecrRefCount(__ll); __ll = NULL; } \
    if (__ll2 != NULL) { Tcl_DecrRefCount(__ll2); __ll2 = NULL; } \
    \
    Tcl_DStringFree(_tmpVar_string_1);\
    Tcl_DStringFree(_tmpVar_string_2);\
    Tcl_DStringFree(__a);\

#define RETURN_VALUE_CLEANUP
#define RETURN_VALUE returnValue
/* 
 * compiled proc implementation 
 *
 */
Tcl_Obj*
TSP_UserDirect_foo(Tcl_Interp* interp, int* rc   ) {
    static int directInit = 0;
    int i;          /* for loop */
    int len;        /* len, idx1, idx2, str, str2 -for use by lang_string, et.al. */
    int idx1;
    int idx2;
    char* str1;     
    char* str2;     
    char* exprErrMsg = NULL;
    Tcl_Obj* _tmpVar_cmdResultObj = NULL;
    /* Tcl_CallFrame commented out not to use internal funcs MiR 2022-04-23
    Tcl_CallFrame* frame = NULL; 
    */
    Tcl_Obj* returnValue = NULL;
    Tcl_Obj*  argObjvArray_0[2];
    int       argObjc_0 = 0;
    Tcl_Obj** foreachObjv_0 = NULL;
    Tcl_Obj*  argObjvArray_1[2];
    int       argObjc_1 = 0;
    Tcl_Obj** foreachObjv_1 = NULL;
    /* stack allocated strings */
    Tcl_DString Proc__tmpVar_string_1;
    Tcl_DString Proc__tmpVar_string_2;
    Tcl_DString Proc___a;
    /* variables defined in proc, plus temp vars */
    Tcl_WideInt _tmpVar_int_1 = 0;
    Tcl_WideInt _tmpVar_int_2 = 0;
    Tcl_DString* _tmpVar_string_1;
    Tcl_DString* _tmpVar_string_2;
    Tcl_Obj* _tmpVar_var_1 = NULL;
    Tcl_Obj* _tmpVar_var_2 = NULL;
    Tcl_DString* __a;
    Tcl_Obj* __buf = NULL;
    Tcl_Obj* __ll = NULL;
    Tcl_Obj* __ll2 = NULL;
    /* constants used for direct tcl and tcl invoked commands */
    /* const: ok */
    static Tcl_Obj* _constant_1 = NULL;
    /* initialize return value */
    /* initialize string vars */
    Tcl_DStringInit(&Proc__tmpVar_string_1);
    _tmpVar_string_1 = &Proc__tmpVar_string_1;
    Tcl_DStringInit(&Proc__tmpVar_string_2);
    _tmpVar_string_2 = &Proc__tmpVar_string_2;
    Tcl_DStringInit(&Proc___a);
    __a = &Proc___a;
    /* var arguments need to be preserved, since they are released in CLEANUP */
    /* string arguments need to be copied (FIXME: investigate using COW for strings) */
    /* initialize function pointers for calling other compiled procs, constants */
    if (! directInit) {
        directInit = 1;
        _constant_1 = TSP_Util_const_string("ok");
    }
    /* Tcl_CallFrame is dangerous since it is buried deep in the tcl_internals stubs table */
    /* could easily break in future TCL_VERSION versions */
    /* Made it functional against 8.6.6 with no guarantee */
    /* Commented out not to use internal funcs MiR 2022-04-23 */
    /* Maybe this has sideeffects like polluting the global namespace when spilling vars*/
    /*
    frame = (Tcl_CallFrame*) ckalloc(sizeof(Tcl_CallFrame));
    Tcl_PushCallFrame(interp, frame, Tcl_GetGlobalNamespace(interp), 1);
    */
    *rc = TCL_OK;     
    /* code must return a value as defined by procdef (unless void), else will raise a compile error */
    /* does only gcc do this with the right option?  what about tcc/clang/msvc++? */
    /******** foo 4: set ll {} */
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_string */
    __ll = TSP_Util_lang_assign_var_string_const(__ll, "");
    /******** foo 5: set ll2 {} */
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_string */
    __ll2 = TSP_Util_lang_assign_var_string_const(__ll2, "");
    /******** foo 6: puts "ok"; */
    /***** ::tsp::gen_direct_tcl puts */
    argObjvArray_0[0] = NULL;
    argObjvArray_0[1] = _constant_1;
    /*  ::tsp::lang_invoke_builtin */
    if ((*rc = (TSP_Cmd_builtin_puts) ((ClientData)NULL, interp,  2, argObjvArray_0)) != TCL_OK) {
        ERROR_EXIT;
    }
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } 
    _tmpVar_cmdResultObj = Tcl_GetObjResult(interp);
    Tcl_IncrRefCount(_tmpVar_cmdResultObj);
    /******** foo 7: set a "test" */
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_string_const */
    Tcl_DStringSetLength(__a,0);
    Tcl_DStringAppend(__a, "test", -1);
    /******** foo 8: puts "ok for $a" */
    /***** ::tsp::gen_direct_tcl puts */
    argObjvArray_0[0] = NULL;
    /***** ::tsp::gen_assign_var_string_interpolated_string */
    /* ::tsp::lang_assign_empty_zero */
    Tcl_DStringSetLength(_tmpVar_string_2, 0);
    /* ::tsp::lang_assign_string_const */
    Tcl_DStringSetLength(_tmpVar_string_1,0);
    Tcl_DStringAppend(_tmpVar_string_1, "ok for ", -1);
    /* ::tsp::lang_append_string */
    Tcl_DStringAppend(_tmpVar_string_2, Tcl_DStringValue(_tmpVar_string_1), Tcl_DStringLength(_tmpVar_string_1));
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_convert_string_string */
    Tcl_DStringSetLength(_tmpVar_string_1,0);
    Tcl_DStringAppend(_tmpVar_string_1, Tcl_DStringValue(__a), Tcl_DStringLength(__a));
    /* ::tsp::lang_append_string */
    Tcl_DStringAppend(_tmpVar_string_2, Tcl_DStringValue(_tmpVar_string_1), Tcl_DStringLength(_tmpVar_string_1));
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_assign_var_string */
    _tmpVar_var_1 = TSP_Util_lang_assign_var_string(_tmpVar_var_1, _tmpVar_string_2);
    argObjvArray_0[1] = _tmpVar_var_1;
    /*  ::tsp::lang_invoke_builtin */
    if ((*rc = (TSP_Cmd_builtin_puts) ((ClientData)NULL, interp,  2, argObjvArray_0)) != TCL_OK) {
        ERROR_EXIT;
    }
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } 
    _tmpVar_cmdResultObj = Tcl_GetObjResult(interp);
    Tcl_IncrRefCount(_tmpVar_cmdResultObj);
    /******** foo 9: set ll [list 0 8 7 1 2 3] */
    /***** ::tsp::generate_set assign from command */
    /******** foo 9: list 0 8 7 1 2 3 */
    /***** ::tsp::gen_command_list */
    if (_tmpVar_var_1 != NULL) { Tcl_DecrRefCount(_tmpVar_var_1); _tmpVar_var_1 = NULL; } 
    _tmpVar_var_1 = Tcl_NewListObj(0, NULL);
    if (_tmpVar_var_2 != NULL) { Tcl_DecrRefCount(_tmpVar_var_2); _tmpVar_var_2 = NULL; } 
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_int */
    _tmpVar_var_2 = TSP_Util_lang_assign_var_int(_tmpVar_var_2, (TCL_WIDE_INT_TYPE) 0);
    /* ::tsp::lang_lappend_var */
    Tcl_ListObjAppendElement(interp, _tmpVar_var_1, _tmpVar_var_2);
    if (_tmpVar_var_2 != NULL) { Tcl_DecrRefCount(_tmpVar_var_2); _tmpVar_var_2 = NULL; } 
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_int */
    _tmpVar_var_2 = TSP_Util_lang_assign_var_int(_tmpVar_var_2, (TCL_WIDE_INT_TYPE) 8);
    /* ::tsp::lang_lappend_var */
    Tcl_ListObjAppendElement(interp, _tmpVar_var_1, _tmpVar_var_2);
    if (_tmpVar_var_2 != NULL) { Tcl_DecrRefCount(_tmpVar_var_2); _tmpVar_var_2 = NULL; } 
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_int */
    _tmpVar_var_2 = TSP_Util_lang_assign_var_int(_tmpVar_var_2, (TCL_WIDE_INT_TYPE) 7);
    /* ::tsp::lang_lappend_var */
    Tcl_ListObjAppendElement(interp, _tmpVar_var_1, _tmpVar_var_2);
    if (_tmpVar_var_2 != NULL) { Tcl_DecrRefCount(_tmpVar_var_2); _tmpVar_var_2 = NULL; } 
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_int */
    _tmpVar_var_2 = TSP_Util_lang_assign_var_int(_tmpVar_var_2, (TCL_WIDE_INT_TYPE) 1);
    /* ::tsp::lang_lappend_var */
    Tcl_ListObjAppendElement(interp, _tmpVar_var_1, _tmpVar_var_2);
    if (_tmpVar_var_2 != NULL) { Tcl_DecrRefCount(_tmpVar_var_2); _tmpVar_var_2 = NULL; } 
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_int */
    _tmpVar_var_2 = TSP_Util_lang_assign_var_int(_tmpVar_var_2, (TCL_WIDE_INT_TYPE) 2);
    /* ::tsp::lang_lappend_var */
    Tcl_ListObjAppendElement(interp, _tmpVar_var_1, _tmpVar_var_2);
    if (_tmpVar_var_2 != NULL) { Tcl_DecrRefCount(_tmpVar_var_2); _tmpVar_var_2 = NULL; } 
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_int */
    _tmpVar_var_2 = TSP_Util_lang_assign_var_int(_tmpVar_var_2, (TCL_WIDE_INT_TYPE) 3);
    /* ::tsp::lang_lappend_var */
    Tcl_ListObjAppendElement(interp, _tmpVar_var_1, _tmpVar_var_2);
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_assign_var_var */
    __ll = TSP_Util_lang_assign_var_var(__ll, _tmpVar_var_1);
    /******** foo 10: set ll2 [lsort $ll] */
    /***** ::tsp::generate_set assign from command */
    /******** foo 10: lsort $ll */
    /***** ::tsp::gen_direct_tcl lsort */
    argObjvArray_1[0] = NULL;
    argObjvArray_1[1] = __ll;
    /*  ::tsp::lang_invoke_builtin */
    if ((*rc = (TSP_Cmd_builtin_lsort) ((ClientData)NULL, interp,  2, argObjvArray_1)) != TCL_OK) {
        ERROR_EXIT;
    }
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } 
    _tmpVar_cmdResultObj = Tcl_GetObjResult(interp);
    Tcl_IncrRefCount(_tmpVar_cmdResultObj);
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_assign_var_var */
    __ll2 = TSP_Util_lang_assign_var_var(__ll2, _tmpVar_cmdResultObj);
    /******** foo 12: foreach buf $ll2 {.            puts $buf.        } */
    /***** ::tsp::gen_command_foreach */
    /* ::tsp::lang_foreach */
    /* ::tsp::lang_assign_var_var */
    _tmpVar_var_1 = TSP_Util_lang_assign_var_var(_tmpVar_var_1, __ll2);
    _tmpVar_int_1 = 0; /* idx */
    if ((*rc = Tcl_ListObjGetElements(interp, _tmpVar_var_1, &len, &foreachObjv_0)) != TCL_OK) { 
        ERROR_EXIT;
    }
    _tmpVar_int_2 = len; /* list length */
    while (_tmpVar_int_1 < _tmpVar_int_2) {
        /* foreach set var buf */
        if (_tmpVar_int_1 < _tmpVar_int_2) {
            if (__buf != NULL) { Tcl_DecrRefCount(__buf); __buf = NULL; } 
            __buf = *(foreachObjv_0+_tmpVar_int_1++);
            Tcl_IncrRefCount(__buf);
        } else {
            /* ::tsp::lang_assign_empty_zero */
            if (__buf != NULL) { Tcl_DecrRefCount(__buf); __buf = NULL; } 
            __buf = Tcl_NewStringObj("",-1);
            Tcl_IncrRefCount(__buf);
        }
        /* foreach body */
        /******** foo 13: puts $buf */
        /***** ::tsp::gen_direct_tcl puts */
        argObjvArray_0[0] = NULL;
        argObjvArray_0[1] = __buf;
        /*  ::tsp::lang_invoke_builtin */
        if ((*rc = (TSP_Cmd_builtin_puts) ((ClientData)NULL, interp,  2, argObjvArray_0)) != TCL_OK) {
            ERROR_EXIT;
        }
        if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } 
        _tmpVar_cmdResultObj = Tcl_GetObjResult(interp);
        Tcl_IncrRefCount(_tmpVar_cmdResultObj);
        /* foreach body end */
    }
    /******** foo 15: puts "ok ll $ll" */
    /***** ::tsp::gen_direct_tcl puts */
    argObjvArray_0[0] = NULL;
    /***** ::tsp::gen_assign_var_string_interpolated_string */
    /* ::tsp::lang_assign_empty_zero */
    Tcl_DStringSetLength(_tmpVar_string_2, 0);
    /* ::tsp::lang_assign_string_const */
    Tcl_DStringSetLength(_tmpVar_string_1,0);
    Tcl_DStringAppend(_tmpVar_string_1, "ok ll ", -1);
    /* ::tsp::lang_append_string */
    Tcl_DStringAppend(_tmpVar_string_2, Tcl_DStringValue(_tmpVar_string_1), Tcl_DStringLength(_tmpVar_string_1));
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_convert_string_var */
    Tcl_DStringSetLength(_tmpVar_string_1, 0);
    _tmpVar_string_1 = TSP_Util_lang_convert_string_var(_tmpVar_string_1, __ll);
    /* ::tsp::lang_append_string */
    Tcl_DStringAppend(_tmpVar_string_2, Tcl_DStringValue(_tmpVar_string_1), Tcl_DStringLength(_tmpVar_string_1));
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_assign_var_string */
    _tmpVar_var_1 = TSP_Util_lang_assign_var_string(_tmpVar_var_1, _tmpVar_string_2);
    argObjvArray_0[1] = _tmpVar_var_1;
    /*  ::tsp::lang_invoke_builtin */
    if ((*rc = (TSP_Cmd_builtin_puts) ((ClientData)NULL, interp,  2, argObjvArray_0)) != TCL_OK) {
        ERROR_EXIT;
    }
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } 
    _tmpVar_cmdResultObj = Tcl_GetObjResult(interp);
    Tcl_IncrRefCount(_tmpVar_cmdResultObj);
    /******** foo 16: puts "ok ll2 $ll2" */
    /***** ::tsp::gen_direct_tcl puts */
    argObjvArray_0[0] = NULL;
    /***** ::tsp::gen_assign_var_string_interpolated_string */
    /* ::tsp::lang_assign_empty_zero */
    Tcl_DStringSetLength(_tmpVar_string_2, 0);
    /* ::tsp::lang_assign_string_const */
    Tcl_DStringSetLength(_tmpVar_string_1,0);
    Tcl_DStringAppend(_tmpVar_string_1, "ok ll2 ", -1);
    /* ::tsp::lang_append_string */
    Tcl_DStringAppend(_tmpVar_string_2, Tcl_DStringValue(_tmpVar_string_1), Tcl_DStringLength(_tmpVar_string_1));
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_convert_string_var */
    Tcl_DStringSetLength(_tmpVar_string_1, 0);
    _tmpVar_string_1 = TSP_Util_lang_convert_string_var(_tmpVar_string_1, __ll2);
    /* ::tsp::lang_append_string */
    Tcl_DStringAppend(_tmpVar_string_2, Tcl_DStringValue(_tmpVar_string_1), Tcl_DStringLength(_tmpVar_string_1));
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_assign_var_string */
    _tmpVar_var_1 = TSP_Util_lang_assign_var_string(_tmpVar_var_1, _tmpVar_string_2);
    argObjvArray_0[1] = _tmpVar_var_1;
    /*  ::tsp::lang_invoke_builtin */
    if ((*rc = (TSP_Cmd_builtin_puts) ((ClientData)NULL, interp,  2, argObjvArray_0)) != TCL_OK) {
        ERROR_EXIT;
    }
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } 
    _tmpVar_cmdResultObj = Tcl_GetObjResult(interp);
    Tcl_IncrRefCount(_tmpVar_cmdResultObj);
    /******** foo 17: return "ok" */
    /***** ::tsp::gen_command_return */
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_string */
    _tmpVar_var_1 = TSP_Util_lang_assign_var_string_const(_tmpVar_var_1, "ok");
    Tcl_IncrRefCount(_tmpVar_var_1);
    /* ::tsp::lang_return */
    returnValue = _tmpVar_var_1;
    Tcl_IncrRefCount(returnValue);
    *rc = TCL_OK;
    CLEANUP;
    /* returnValue is cleaned up by calling proc */;
    return RETURN_VALUE;
    /* if void, then we can jump to normal_exit, if not-void, then that means the proc fell through */
    /* without returning a value.  in that case, set result and return error code*/
    Tcl_SetResult(interp, "end of proc encountered without 'return' command, proc type: var", TCL_STATIC); goto error_exit;    
  error_exit:
    *rc = TCL_ERROR;
  normal_exit:
    CLEANUP;
    RETURN_VALUE_CLEANUP;
    return RETURN_VALUE;
}
/* redefine macros for the Tcl interface function */
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define CLEANUP \

#define RETURN_VALUE_CLEANUP 
#define RETURN_VALUE 
#define ERROR_EXIT goto error_exit
/* 
 * Tcl command interface 
 *
 */
int foo(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) {
    int _rc;
    int* rc = &_rc;;
    Tcl_Obj* returnValue = NULL;
    /* variables used by this command, assigned from objv array */
    /* allow other compiled procs to find the this proc function at runtime, see TSP_cmd.TSP_User_getCmd() */
    if (clientData != NULL && objc == 0) {
        void** cd = clientData;
        *cd = (void*) TSP_UserDirect_foo;
        return TCL_OK;
    }
    /* check arg count */
    if (objc != 1) {
        Tcl_WrongNumArgs(interp, 1, objv, "");
        return TCL_ERROR;
    }
    /* assign arg variable from objv array */
    /* invoke compiled proc method */
    _rc = TCL_OK;
    returnValue = TSP_UserDirect_foo(interp, &_rc );
    if (_rc == TCL_OK) {
        Tcl_SetObjResult(interp, returnValue);
        /* ok to fall through */
    }
  error_exit:
    CLEANUP;
    return _rc;
}
__declspec(dllexport) 
int Testpkg_Init(Tcl_Interp *interp) {
#ifdef USE_TCL_STUBS
  if (Tcl_InitStubs(interp, TCL_VERSION, 0) == 0L) {
    return TCL_ERROR;
  }
#endif
#ifdef USE_TK_STUBS
  if (Tk_InitStubs(interp, TCL_VERSION, 0) == 0L) {
    return TCL_ERROR;
  }
#endif
  Tcl_CreateObjCommand(interp, "::fib0", fib0, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::fib", fib, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::wordsplit", wordsplit, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::foo", foo, NULL, NULL);
  Tcl_PkgProvide(interp, "testpkg", "1.0");
  return(TCL_OK);
}

