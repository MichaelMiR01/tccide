#ifndef MINGW_DDK_H
#define MINGW_DDK_H
#if 1
#define MINGW_HAS_DDK_H 1
#endif
#endif
