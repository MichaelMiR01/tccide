#include <stdio.h>

int main()
{
   printf("including\n");
#include "18_include.h"
   printf("done\n");

   return 0;
}

/* vim: set expandtab ts=4 sw=3 sts=3 tw=80 :*/
