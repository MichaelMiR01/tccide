gcc -Wfatal-errors -fPIC -D_GNU_SOURCE -DTCC_TARGET_X86_64 -DONE_SOURCE -DLIBTCC_AS_DLL -DUSE_TCL_STUBS -I../tcc_0.9.27-bin/include/generic -c tcc-0-9-27/tcc.c   -L../tcc_0.9.27-bin/lib  -o"libtcc.o" -O2 
read -rsp $'Press enter to continue...\n'
gcc -Wfatal-errors -fPIC -DTCC_TARGET_X86_64 -DONE_SOURCE -DLIBTCC_AS_DLL -DUSE_TCL_STUBS -I../tcc_0.9.27-bin/include/generic -I../tcc_0.9.27-bin/include/generic/unix -Itcc-0-9-27 -c tcc4tcl_0927.c  -L../tcc_0.9.27-bin/lib -ltclstub86_64 -o"tcc4tcl.o" -O2 
read -rsp $'Press enter to continue...\n'

gcc -shared -s -o tcc4tcl.so libtcc.o tcc4tcl.o  -L"../tcc_0.9.27-bin/lib" -ltclstub86_64 
read -rsp $'Press enter to continue...\n'

cp tcc4tcl.so ../tccide.vfs/lib/tcc4tcl-0.30/tcc4tcl.so
read -rsp $'Press enter to continue...\n'
