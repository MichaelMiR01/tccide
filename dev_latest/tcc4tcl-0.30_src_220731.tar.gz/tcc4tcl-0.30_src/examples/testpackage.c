/* ./tcc.exe -shared -Iinclude/ -Iinclude/1 -Iinclude/generic -Iinclude/sdks -Iinclude/sec_api -Iinclude/sec_api/sys -Iinclude/sys -Iinclude/winapi -Iinclude/xlib -Iinclude/xlib/X11 -Itccimglib -Itccimglib/jpeg testpackage.c -ltclstub86elf -ltkstub86elf -ljpeg62*/
/* i686-w64-mingw32-gcc -m32 -s -shared -Iincludetcl -Iinclude/xlib ./examples/testpackage.c -Llib -ltclstub86 -ltkstub86 -otestpkg.dll*/


#define USE_TCL_STUBS 1
#include <tcl.h>
#define USE_TK_STUBS 1
#include <tk.h>

/* Helper for Debugging*/
char __s[250];
char __buf2 [260];
Tcl_Interp *debug_interp; 
int vspfunc(char const *format, ...) {
    char __buf[250];
    
    va_list aptr;
    int ret;
    va_start(aptr, format);
    ret = vsprintf(__buf, format, aptr);
    va_end(aptr);
    sprintf(__buf2, "puts \"%s\"", __buf);
    
    return 1;
}


#define PUTS(msg) Tcl_Eval(debug_interp, "puts \""msg"\"");
#define PUTSV(msg,...) vspfunc(msg, __VA_ARGS__); Tcl_Eval(debug_interp,__buf2);

#define PUTV(msg,v) sprintf(__s, "puts \"%s: %d\"", msg,v);Tcl_Eval(debug_interp, __s);
#define PUTVS(msg,v) sprintf(__s, "puts \"%s: %s\"", msg,v);Tcl_Eval(debug_interp, __s);

static int c_testPUTS(Tcl_Interp* interp, int v0, char* s0) {
Tcl_Interp *debug_interp; 
    debug_interp= interp;
    //vspfunc("test v0 %d %d", v0, 1);
    //Tcl_Eval(interp,__buf2);
    PUTS("Message only");
    PUTSV("Decimal %d",v0);
    PUTSV("Two vars %d %s", v0, s0);
}

int tcl_testPUTS(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  int _v0;
  char* _s0;
  int rv;
  if (objc != 3) {
    Tcl_WrongNumArgs(ip, 1, objv, "v0 s0");
    return TCL_ERROR;
  }
  if (Tcl_GetIntFromObj(ip, objv[1], &_v0) != TCL_OK)    return TCL_ERROR;
  _s0 = Tcl_GetString(objv[2]);

  rv = c_testPUTS(ip, _v0, _s0);
  Tcl_SetIntObj(Tcl_GetObjResult(ip), rv);
  return TCL_OK;
}


__declspec(dllexport) 
int Testpackage_Init(Tcl_Interp *interp) {
#ifdef USE_TCL_STUBS
  if (Tcl_InitStubs(interp, TCL_VERSION, 0) == 0L) {
    return TCL_ERROR;
  }
#endif
#ifdef USE_TK_STUBS
  if (Tk_InitStubs(interp, TCL_VERSION, 0) == 0L) {
    return TCL_ERROR;
  }
#endif
  Tcl_CreateObjCommand(interp, "testPUTS", tcl_testPUTS, NULL, NULL);
  Tcl_PkgProvide(interp, "testpackage", "1.0");
  return(TCL_OK);
}
